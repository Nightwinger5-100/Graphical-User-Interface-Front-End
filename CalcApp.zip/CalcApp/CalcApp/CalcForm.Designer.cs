﻿namespace CalcApp
{
    partial class CalcForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            numOneLabel = new Label();
            numTwoLabel = new Label();
            confirmButton = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            numOneTextBox = new TextBox();
            numTwoTextBox = new TextBox();
            appTitle = new Label();
            SuspendLayout();
            // 
            // numOneLabel
            // 
            numOneLabel.AutoSize = true;
            numOneLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            numOneLabel.Location = new Point(87, 150);
            numOneLabel.Name = "numOneLabel";
            numOneLabel.Size = new Size(171, 20);
            numOneLabel.TabIndex = 0;
            numOneLabel.Text = "Input number one here";
            // 
            // numTwoLabel
            // 
            numTwoLabel.AutoSize = true;
            numTwoLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            numTwoLabel.Location = new Point(553, 150);
            numTwoLabel.Name = "numTwoLabel";
            numTwoLabel.Size = new Size(172, 20);
            numTwoLabel.TabIndex = 1;
            numTwoLabel.Text = "Input number two here";
            // 
            // confirmButton
            // 
            confirmButton.Location = new Point(356, 392);
            confirmButton.Name = "confirmButton";
            confirmButton.Size = new Size(94, 29);
            confirmButton.TabIndex = 2;
            confirmButton.Text = "Confirm";
            confirmButton.UseVisualStyleBackColor = true;
            confirmButton.Click += confirmIfInt;
            // 
            // button1
            // 
            button1.BackColor = Color.Turquoise;
            button1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(235, 245);
            button1.Name = "button1";
            button1.Size = new Size(104, 53);
            button1.TabIndex = 3;
            button1.Text = "+";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Cornsilk;
            button2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(235, 321);
            button2.Name = "button2";
            button2.Size = new Size(104, 53);
            button2.TabIndex = 4;
            button2.Text = "x";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Crimson;
            button3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(470, 245);
            button3.Name = "button3";
            button3.Size = new Size(104, 53);
            button3.TabIndex = 5;
            button3.Text = "-";
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.Gray;
            button4.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(470, 321);
            button4.Name = "button4";
            button4.Size = new Size(104, 53);
            button4.TabIndex = 6;
            button4.Text = "/";
            button4.UseVisualStyleBackColor = false;
            // 
            // numOneTextBox
            // 
            numOneTextBox.Location = new Point(103, 185);
            numOneTextBox.Name = "numOneTextBox";
            numOneTextBox.Size = new Size(125, 27);
            numOneTextBox.TabIndex = 7;
            // 
            // numTwoTextBox
            // 
            numTwoTextBox.Location = new Point(572, 185);
            numTwoTextBox.Name = "numTwoTextBox";
            numTwoTextBox.Size = new Size(125, 27);
            numTwoTextBox.TabIndex = 8;
            // 
            // appTitle
            // 
            appTitle.AutoSize = true;
            appTitle.Font = new Font("Showcard Gothic", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            appTitle.Location = new Point(144, 28);
            appTitle.Name = "appTitle";
            appTitle.Size = new Size(519, 74);
            appTitle.TabIndex = 9;
            appTitle.Text = "Ca1cu1ator App";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOrchid;
            ClientSize = new Size(800, 450);
            Controls.Add(appTitle);
            Controls.Add(numTwoTextBox);
            Controls.Add(numOneTextBox);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(confirmButton);
            Controls.Add(numTwoLabel);
            Controls.Add(numOneLabel);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label numOneLabel;
        private Label numTwoLabel;
        private Button confirmButton;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private TextBox numOneTextBox;
        private TextBox numTwoTextBox;
        private Label appTitle;
    }
}
