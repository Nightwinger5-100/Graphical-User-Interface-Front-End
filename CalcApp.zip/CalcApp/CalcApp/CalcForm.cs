namespace CalcApp
{
    public partial class CalcForm : Form
    {
        int number1;
        int number2;
        public CalcForm()
        {
            InitializeComponent();
        }

        private void confirmIfInt(object sender, EventArgs e)
        {
            {
                //if the first input returns as a number...
                if (int.TryParse(numOneTextBox.Text, out number1))
                {
                    //if the second input returns as a number, show the first and second numbers
                    if (int.TryParse(numTwoTextBox.Text, out number2))
                    {
                        MessageBox.Show(numOneTextBox.Text + "" + numTwoTextBox.Text);
                    }
                    else
                    {
                        //clear the text box return invalid
                        numTwoTextBox.Clear();
                        MessageBox.Show("Invalid input @ the second number");
                    }
                }
                else
                {
                    //clear the text box return invalid
                    numOneTextBox.Clear();
                    MessageBox.Show("Invalid input @ the first number");
                }
            }
        }
    }
}
