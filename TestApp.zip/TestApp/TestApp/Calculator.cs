namespace TestApp
{
    public partial class GUIForm : Form
    {
        int number1;
        int number2;
        public GUIForm()
        {
            InitializeComponent();
        }


        //checks if the input given is a int
        private void confirmIfInt_Click(object sender, EventArgs e)
        {
            //if the first input returns as a number...
            if (int.TryParse(inputNumOneTextBox.Text, out number1))
            {
                //if the second input returns as a number, show the first and second numbers
                if (int.TryParse(inputNumTwoTextBox.Text, out number2))
                {
                    MessageBox.Show(inputNumOneTextBox.Text + "" + inputNumTwoTextBox.Text);
                }
                else
                {
                    //clear the text box return invalid
                    inputNumTwoTextBox.Clear();
                    MessageBox.Show("Invalid input @ the second number");
                }
            }
            else
            {
                //clear the text box return invalid
                inputNumOneTextBox.Clear();
                MessageBox.Show("Invalid input @ the first number");
            }
        }

        private void input_num_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleLabel_Click(object sender, EventArgs e)
        {

        }

        private void input_number_label_Click(object sender, EventArgs e)
        {

        }

        private void numberTwoLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
