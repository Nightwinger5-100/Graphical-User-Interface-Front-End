﻿namespace TestApp
{
    partial class GUIForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            multiplyButton = new Button();
            inputNumOneTextBox = new TextBox();
            numberOneLabel = new Label();
            titleLabel = new Label();
            numberTwoLabel = new Label();
            inputNumTwoTextBox = new TextBox();
            subtractButton = new Button();
            addButton = new Button();
            divideButton = new Button();
            SuspendLayout();
            // 
            // multiplyButton
            // 
            multiplyButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            multiplyButton.BackColor = SystemColors.HotTrack;
            multiplyButton.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            multiplyButton.Location = new Point(218, 349);
            multiplyButton.Name = "multiplyButton";
            multiplyButton.Size = new Size(134, 62);
            multiplyButton.TabIndex = 0;
            multiplyButton.Text = "X";
            multiplyButton.UseVisualStyleBackColor = false;
            multiplyButton.Click += confirmIfInt_Click;
            // 
            // inputNumOneTextBox
            // 
            inputNumOneTextBox.Location = new Point(83, 119);
            inputNumOneTextBox.Name = "inputNumOneTextBox";
            inputNumOneTextBox.Size = new Size(215, 27);
            inputNumOneTextBox.TabIndex = 1;
            inputNumOneTextBox.TextChanged += input_num_textbox_TextChanged;
            // 
            // numberOneLabel
            // 
            numberOneLabel.AutoSize = true;
            numberOneLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            numberOneLabel.Location = new Point(113, 96);
            numberOneLabel.Name = "numberOneLabel";
            numberOneLabel.Size = new Size(164, 20);
            numberOneLabel.TabIndex = 2;
            numberOneLabel.Text = "Input a number below";
            numberOneLabel.Click += input_number_label_Click;
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.BorderStyle = BorderStyle.FixedSingle;
            titleLabel.Font = new Font("Showcard Gothic", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleLabel.Location = new Point(218, 24);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(364, 45);
            titleLabel.TabIndex = 3;
            titleLabel.Text = "Simp1e Ca1cu1ator";
            titleLabel.Click += titleLabel_Click;
            // 
            // numberTwoLabel
            // 
            numberTwoLabel.AutoSize = true;
            numberTwoLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            numberTwoLabel.ImageAlign = ContentAlignment.MiddleLeft;
            numberTwoLabel.Location = new Point(394, 96);
            numberTwoLabel.Name = "numberTwoLabel";
            numberTwoLabel.Size = new Size(407, 20);
            numberTwoLabel.TabIndex = 5;
            numberTwoLabel.Text = "Input a number below to apply to the number on the left";
            numberTwoLabel.TextAlign = ContentAlignment.MiddleCenter;
            numberTwoLabel.UseWaitCursor = true;
            numberTwoLabel.Click += numberTwoLabel_Click;
            // 
            // inputNumTwoTextBox
            // 
            inputNumTwoTextBox.Location = new Point(505, 119);
            inputNumTwoTextBox.Name = "inputNumTwoTextBox";
            inputNumTwoTextBox.Size = new Size(215, 27);
            inputNumTwoTextBox.TabIndex = 4;
            // 
            // subtractButton
            // 
            subtractButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            subtractButton.BackColor = SystemColors.Info;
            subtractButton.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            subtractButton.Location = new Point(464, 235);
            subtractButton.Name = "subtractButton";
            subtractButton.Size = new Size(134, 62);
            subtractButton.TabIndex = 6;
            subtractButton.Text = "-";
            subtractButton.UseVisualStyleBackColor = false;
            subtractButton.Click += confirmIfInt_Click;
            // 
            // addButton
            // 
            addButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            addButton.BackColor = SystemColors.ActiveCaption;
            addButton.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addButton.Location = new Point(218, 235);
            addButton.Name = "addButton";
            addButton.Size = new Size(134, 62);
            addButton.TabIndex = 7;
            addButton.Text = "+";
            addButton.UseVisualStyleBackColor = false;
            addButton.Click += confirmIfInt_Click;
            // 
            // divideButton
            // 
            divideButton.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            divideButton.AutoSize = true;
            divideButton.BackColor = SystemColors.ScrollBar;
            divideButton.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            divideButton.Location = new Point(464, 349);
            divideButton.Name = "divideButton";
            divideButton.Size = new Size(134, 62);
            divideButton.TabIndex = 8;
            divideButton.Text = "/";
            divideButton.UseVisualStyleBackColor = false;
            divideButton.Click += confirmIfInt_Click;
            // 
            // GUIForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Coral;
            ClientSize = new Size(800, 450);
            Controls.Add(divideButton);
            Controls.Add(addButton);
            Controls.Add(subtractButton);
            Controls.Add(numberTwoLabel);
            Controls.Add(inputNumTwoTextBox);
            Controls.Add(titleLabel);
            Controls.Add(numberOneLabel);
            Controls.Add(inputNumOneTextBox);
            Controls.Add(multiplyButton);
            ForeColor = Color.Black;
            Name = "GUIForm";
            Text = "GUI";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button multiplyButton;
        private TextBox inputNumOneTextBox;
        private Label numberOneLabel;
        private Label titleLabel;
        private Label numberTwoLabel;
        private TextBox inputNumTwoTextBox;
        private Button subtractButton;
        private Button addButton;
        private Button divideButton;
    }
}
